package com.example.anakkampus;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class fbweb extends AppCompatActivity {
    private WebView webView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fbweb);

        getSupportActionBar().hide();

        webView1 = (WebView) findViewById(R.id.webviewfb);
        webView1.setWebViewClient(new WebViewClient());
        webView1.loadUrl("https://www.facebook.com/");
    }
}