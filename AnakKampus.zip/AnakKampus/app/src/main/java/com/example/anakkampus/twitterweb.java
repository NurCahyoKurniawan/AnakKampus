package com.example.anakkampus;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class twitterweb extends AppCompatActivity {
    private WebView webView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twitterweb);

        getSupportActionBar().hide();

        webView2 = (WebView) findViewById(R.id.webviewtwitter);
        webView2.setWebViewClient(new WebViewClient());
        webView2.loadUrl("https://www.twitter.com/");
    }
}