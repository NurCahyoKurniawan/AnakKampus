package com.example.anakkampus;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button button;
    ImageButton logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        logo = (ImageButton) findViewById(R.id.imagebutton);
        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openweb();
            }
        });
        logo = (ImageButton) findViewById(R.id.imagebutton2);
        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openweb1();
            }
        });
        logo = (ImageButton) findViewById(R.id.imagebutton3);
        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openweb2();
            }
        });
        button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { openweb3(); }
        });
    }

    private void openweb3() {
        Intent intent = new Intent(this, menu1.class);
        startActivity(intent);
    }

    private void openweb2() {
        Intent intent = new Intent(this, fbweb.class);
        startActivity(intent);
    }

    private void openweb1() {
        Intent intent = new Intent(this, twitterweb.class);
        startActivity(intent);

    }

    private void openweb() {
            Intent intent = new Intent(this, web.class);
            startActivity(intent);
    }
}